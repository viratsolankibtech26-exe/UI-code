/* ---------------------------------------------------------------
   DESIGN TOKENS
   Navy (#334463) header/nav, warm parchment (#F2E9D8) surface,
   clay-orange (#E38A54) + slate-teal (#3F8C8C) as the two accents
   pulled directly from the one-pager's two dot colors.
   Display face: "Fraunces" (the pager's serif headline) for H1/H2,
   "Inter" for everything functional (numbers, tables, labels).
----------------------------------------------------------------- */
export const COLORS = {
  navy: "#334463",
  navyDark: "#26344C",
  parchment: "#F2E9D8",
  parchmentDeep: "#E9DCC2",
  ink: "#2A2620",
  orange: "#E38A54",
  teal: "#3F8C8C",
  green: "#4C8C5B",
  red: "#C1554B",
  muted: "#8A8271",
};

export const FONT_IMPORT = `@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Inter:wght@400;500;600;700&display=swap');`;

/* Responsive layout rules — sidebar collapses to a horizontal, scrollable
   top bar under ~720px so this behaves on Android/phone widths. */
export const RESPONSIVE_CSS = `
  * { box-sizing: border-box; }
  .app-shell { display: flex; min-height: 100vh; }
  .sidebar {
    width: 210px; flex-shrink: 0; background: ${COLORS.navyDark}; color: #fff;
    padding: 22px 14px; display: flex; flex-direction: column;
  }
  .sidebar-brand { display: flex; gap: 6px; align-items: center; padding: 0 8px 20px; flex-shrink: 0; }
  .nav-btn {
    display: flex; align-items: center; gap: 10px; padding: 10px 12px; margin-bottom: 4px;
    border-radius: 8px; border: none; cursor: pointer; text-align: left; width: 100%;
    font-size: 13.5px; font-weight: 600; background: transparent; color: #B9C2D4;
    font-family: 'Inter', sans-serif;
  }
  .nav-btn.active { background: rgba(255,255,255,0.14); color: #fff; }
  .sidebar-spacer { flex: 1; }
  .sidebar-footer { border-top: 1px solid rgba(255,255,255,0.12); padding-top: 14px; font-size: 12.5px; }
  .logout-btn {
    display: flex; align-items: center; gap: 6px; background: transparent; border: none;
    color: #B9C2D4; cursor: pointer; font-size: 12.5px; padding: 0; font-family: 'Inter', sans-serif;
  }
  .main-content { flex: 1; min-width: 0; padding: 26px 32px; overflow-x: auto; }
  .mobile-topbar { display: none; }

  @media (max-width: 720px) {
    .app-shell { flex-direction: column; }
    .sidebar {
      width: 100%; flex-direction: row; align-items: center; padding: 10px 10px;
      overflow-x: auto; position: sticky; top: 0; z-index: 30; gap: 2px;
    }
    .sidebar-brand { padding: 0 10px 0 0; }
    .nav-btn { flex-direction: column; gap: 3px; width: auto; padding: 7px 10px; font-size: 10.5px; white-space: nowrap; margin-bottom: 0; }
    .sidebar-spacer, .sidebar-footer { display: none; }
    .main-content { padding: 14px; }
    .mobile-topbar {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid ${COLORS.parchmentDeep};
    }
  }
`;

export const inputStyle = {
  width: "100%", padding: "9px 11px", borderRadius: 8, border: "1px solid #DDD3BC",
  fontFamily: "Inter, sans-serif", fontSize: 13.5, boxSizing: "border-box", background: "#FCFAF4",
};
