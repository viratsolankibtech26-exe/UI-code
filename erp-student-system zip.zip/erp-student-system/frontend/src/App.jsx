import React, { useState, useEffect, useCallback } from "react";
import { Users, CalendarCheck, Wallet, LayoutDashboard, LogOut } from "lucide-react";
import { COLORS, FONT_IMPORT, RESPONSIVE_CSS } from "./styles/theme.js";
import { api } from "./api.js";
import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import StudentsPage from "./pages/StudentsPage.jsx";
import AttendancePage from "./pages/AttendancePage.jsx";
import FeesResultsPage from "./pages/FeesResultsPage.jsx";

export default function App() {
  const [user, setUser] = useState(null);
  const [tab, setTab] = useState("dashboard");
  const [students, setStudents] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [fees, setFees] = useState([]);
  const [results, setResults] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [loadError, setLoadError] = useState("");

  const refreshStudents = useCallback(() => api.listStudents().then(setStudents), []);
  const refreshAttendance = useCallback(() => api.listAttendance().then(setAttendance), []);
  const refreshFees = useCallback(() => api.listFees().then(setFees), []);
  const refreshResults = useCallback(() => api.listResults().then(setResults), []);

  useEffect(() => {
    if (!user) return;
    setLoaded(false);
    Promise.all([refreshStudents(), refreshAttendance(), refreshFees(), refreshResults()])
      .then(() => setLoaded(true))
      .catch((e) => setLoadError(e.message));
  }, [user, refreshStudents, refreshAttendance, refreshFees, refreshResults]);

  if (!user) return <Login onLogin={setUser} />;

  const isAdmin = user.role === "admin";
  const isFaculty = user.role === "faculty";

  const navItems = [
    { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { key: "students", label: "Students", icon: Users },
    { key: "attendance", label: "Attendance", icon: CalendarCheck },
    { key: "fees", label: "Fees & Results", icon: Wallet },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "#FBF8F1", fontFamily: "Inter, sans-serif", color: COLORS.ink }}>
      <style>{FONT_IMPORT}{RESPONSIVE_CSS}</style>
      <div className="app-shell">
        {/* Sidebar / mobile top bar */}
        <div className="sidebar">
          <div className="sidebar-brand">
            <span style={{ width: 10, height: 10, borderRadius: "50%", background: COLORS.orange, display: "inline-block" }} />
            <span style={{ width: 8, height: 8, borderRadius: "50%", background: COLORS.teal, display: "inline-block" }} />
            <span style={{ fontFamily: "Fraunces, serif", fontSize: 15, marginLeft: 4, whiteSpace: "nowrap" }}>Campus ERP</span>
          </div>
          {navItems.map((n) => (
            <button key={n.key} onClick={() => setTab(n.key)} className={`nav-btn${tab === n.key ? " active" : ""}`}>
              <n.icon size={16} /> <span>{n.label}</span>
            </button>
          ))}
          <div className="sidebar-spacer" />
          <div className="sidebar-footer">
            <div style={{ fontWeight: 600 }}>{user.name}</div>
            <div style={{ color: "#9AA6BC", textTransform: "capitalize", marginBottom: 10 }}>{user.role}</div>
            <button onClick={() => setUser(null)} className="logout-btn"><LogOut size={13} /> Log out</button>
          </div>
        </div>

        {/* Main */}
        <div className="main-content">
          <div className="mobile-topbar">
            <div>
              <div style={{ fontWeight: 700, fontSize: 13.5 }}>{user.name}</div>
              <div style={{ color: COLORS.muted, textTransform: "capitalize", fontSize: 11.5 }}>{user.role}</div>
            </div>
            <button onClick={() => setUser(null)} style={{
              display: "flex", alignItems: "center", gap: 6, background: "transparent",
              border: `1px solid ${COLORS.parchmentDeep}`, borderRadius: 8, padding: "6px 10px",
              color: COLORS.navy, cursor: "pointer", fontSize: 12, fontWeight: 600, fontFamily: "Inter, sans-serif",
            }}><LogOut size={13} /> Log out</button>
          </div>

          {loadError && <p style={{ color: COLORS.red, fontSize: 13 }}>{loadError}</p>}
          {!loaded && !loadError && <p style={{ color: COLORS.muted, fontSize: 13 }}>Loading…</p>}

          {loaded && tab === "dashboard" && (
            <Dashboard students={students} attendance={attendance} fees={fees} results={results} user={user} />
          )}
          {loaded && tab === "students" && (
            <StudentsPage students={students} refreshStudents={refreshStudents} canEdit={isAdmin || isFaculty} canDelete={isAdmin} user={user} />
          )}
          {loaded && tab === "attendance" && (
            <AttendancePage students={students} attendance={attendance} refreshAttendance={refreshAttendance} canEdit={isAdmin || isFaculty} user={user} />
          )}
          {loaded && tab === "fees" && (
            <FeesResultsPage students={students} fees={fees} refreshFees={refreshFees} results={results} refreshResults={refreshResults} canEdit={isAdmin || isFaculty} user={user} />
          )}
        </div>
      </div>
    </div>
  );
}
