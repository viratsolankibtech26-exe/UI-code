const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

async function request(path, options = {}) {
  const res = await fetch(`${API_URL}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  if (res.status === 204) return null;
  return res.json();
}

export const api = {
  // Auth / demo users
  listUsers: (role) => request(`/users${role ? `?role=${role}` : ""}`),
  login: (userId) => request("/users/login", { method: "POST", body: JSON.stringify({ userId }) }),

  // Students
  listStudents: () => request("/students"),
  createStudent: (data) => request("/students", { method: "POST", body: JSON.stringify(data) }),
  updateStudent: (id, data) => request(`/students/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  deleteStudent: (id) => request(`/students/${id}`, { method: "DELETE" }),

  // Attendance
  listAttendance: () => request("/attendance"),
  markAttendance: (data) => request("/attendance", { method: "POST", body: JSON.stringify(data) }),

  // Fees
  listFees: () => request("/fees"),
  updateFeeStatus: (id, status) => request(`/fees/${id}`, { method: "PATCH", body: JSON.stringify({ status }) }),

  // Results
  listResults: () => request("/results"),
  saveResult: (data) => request("/results", { method: "POST", body: JSON.stringify(data) }),
};
