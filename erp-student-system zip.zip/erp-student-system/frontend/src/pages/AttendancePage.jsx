import React, { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { COLORS, inputStyle } from "../styles/theme.js";
import { Card, Pill, PageHeader, SectionLabel } from "../components/ui.jsx";
import { DATES } from "../constants.js";
import { api } from "../api.js";

export default function AttendancePage({ students, attendance, refreshAttendance, canEdit, user }) {
  const [date, setDate] = useState("2026-09-15");
  const [error, setError] = useState("");
  const visible = user.role === "student" ? students.filter((s) => s.id === user.studentId) : students;

  function statusFor(studentId, d) {
    return attendance.find((a) => a.studentId === studentId && a.date === d)?.status || null;
  }

  async function toggle(studentId) {
    const existing = statusFor(studentId, date);
    const nextStatus = existing === "present" ? "absent" : "present";
    try {
      await api.markAttendance({ studentId, date, status: nextStatus });
      await refreshAttendance();
    } catch (e) {
      setError(e.message);
    }
  }

  const pctByStudent = (id) => {
    const rows = attendance.filter((a) => a.studentId === id);
    if (!rows.length) return 0;
    return Math.round((rows.filter((a) => a.status === "present").length / rows.length) * 100);
  };

  const trend = DATES.map((d) => {
    const dayRows = attendance.filter((a) => a.date === `2026-${d}` && visible.some((s) => s.id === a.studentId));
    const present = dayRows.filter((a) => a.status === "present").length;
    return { date: d, pct: dayRows.length ? Math.round((present / dayRows.length) * 100) : 0 };
  });

  return (
    <div>
      <PageHeader title="Attendance" subtitle="Record attendance and track percentage trends." />

      {error && <p style={{ color: COLORS.red, fontSize: 13 }}>{error}</p>}

      {canEdit && (
        <Card style={{ marginBottom: 16 }}>
          <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 14, flexWrap: "wrap" }}>
            <SectionLabel>Mark attendance for</SectionLabel>
            <select style={{ ...inputStyle, width: 160 }} value={date} onChange={(e) => setDate(e.target.value)}>
              {DATES.map((d) => <option key={d} value={`2026-${d}`}>{`2026-${d}`}</option>)}
            </select>
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {students.map((s) => {
              const st = statusFor(s.id, date);
              return (
                <button key={s.id} onClick={() => toggle(s.id)} style={{
                  padding: "8px 12px", borderRadius: 9, cursor: "pointer", fontSize: 12.5, fontWeight: 600,
                  border: `1px solid ${st === "present" ? "#BFE0BF" : st === "absent" ? "#EFC6C1" : COLORS.parchmentDeep}`,
                  background: st === "present" ? "#E4F3E4" : st === "absent" ? "#FBE7E5" : "#fff",
                  color: st === "present" ? COLORS.green : st === "absent" ? COLORS.red : COLORS.muted,
                }}>
                  {s.name} {st ? `· ${st}` : "· unmarked"}
                </button>
              );
            })}
          </div>
        </Card>
      )}

      <Card style={{ marginBottom: 16 }}>
        <SectionLabel>Attendance trend</SectionLabel>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={trend}>
            <CartesianGrid stroke="#E9DCC2" strokeDasharray="3 3" />
            <XAxis dataKey="date" tick={{ fontSize: 12, fill: COLORS.muted }} />
            <YAxis tick={{ fontSize: 12, fill: COLORS.muted }} domain={[0, 100]} />
            <Tooltip />
            <Bar dataKey="pct" name="Present %" fill={COLORS.teal} radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      <Card style={{ padding: 0, overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13.5, minWidth: 480 }}>
          <thead>
            <tr style={{ textAlign: "left", background: COLORS.parchmentDeep }}>
              <th style={{ padding: "10px 14px", fontSize: 11.5, color: COLORS.muted, fontWeight: 700 }}>Student</th>
              <th style={{ padding: "10px 14px", fontSize: 11.5, color: COLORS.muted, fontWeight: 700 }}>Class</th>
              <th style={{ padding: "10px 14px", fontSize: 11.5, color: COLORS.muted, fontWeight: 700 }}>Attendance %</th>
            </tr>
          </thead>
          <tbody>
            {visible.map((s) => {
              const pct = pctByStudent(s.id);
              return (
                <tr key={s.id} style={{ borderTop: `1px solid ${COLORS.parchmentDeep}` }}>
                  <td style={{ padding: "10px 14px", fontWeight: 600 }}>{s.name}</td>
                  <td style={{ padding: "10px 14px" }}>{s.cls}</td>
                  <td style={{ padding: "10px 14px" }}>
                    <Pill tone={pct >= 75 ? "paid" : pct >= 60 ? "partial" : "pending"}>{pct}%</Pill>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
