import React, { useState } from "react";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { COLORS, inputStyle } from "../styles/theme.js";
import { Card, Button, Modal, Field, PageHeader } from "../components/ui.jsx";
import { api } from "../api.js";

export default function StudentsPage({ students, refreshStudents, canEdit, canDelete, user }) {
  const [modal, setModal] = useState(null); // {mode:'add'|'edit', data}
  const [error, setError] = useState("");
  const visible = user.role === "student" ? students.filter((s) => s.id === user.studentId) : students;

  async function save(form) {
    try {
      if (modal.mode === "add") {
        await api.createStudent({ ...form, gpa: parseFloat(form.gpa) || 0 });
      } else {
        await api.updateStudent(modal.data.id, { ...form, gpa: parseFloat(form.gpa) || 0 });
      }
      await refreshStudents();
      setModal(null);
    } catch (e) {
      setError(e.message);
    }
  }

  async function remove(id) {
    try {
      await api.deleteStudent(id);
      await refreshStudents();
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <PageHeader title="Student Management" subtitle="Centralized records and academic details." />
        {canEdit && (
          <Button variant="orange" onClick={() => setModal({ mode: "add", data: {} })}>
            <Plus size={15} /> Add student
          </Button>
        )}
      </div>

      {error && <p style={{ color: COLORS.red, fontSize: 13 }}>{error}</p>}

      <Card style={{ padding: 0, overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13.5, minWidth: 720 }}>
          <thead>
            <tr style={{ textAlign: "left", background: COLORS.parchmentDeep }}>
              {["Roll", "Name", "Class", "Email", "Phone", "GPA", ""].map((h) => (
                <th key={h} style={{ padding: "10px 14px", fontSize: 11.5, color: COLORS.muted, fontWeight: 700, letterSpacing: 0.3 }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {visible.map((s) => (
              <tr key={s.id} style={{ borderTop: `1px solid ${COLORS.parchmentDeep}` }}>
                <td style={{ padding: "10px 14px", color: COLORS.muted }}>{s.roll}</td>
                <td style={{ padding: "10px 14px", fontWeight: 600 }}>{s.name}</td>
                <td style={{ padding: "10px 14px" }}>{s.cls}</td>
                <td style={{ padding: "10px 14px", color: COLORS.muted }}>{s.email}</td>
                <td style={{ padding: "10px 14px", color: COLORS.muted }}>{s.phone}</td>
                <td style={{ padding: "10px 14px" }}>{s.gpa}</td>
                <td style={{ padding: "10px 14px", textAlign: "right", whiteSpace: "nowrap" }}>
                  {canEdit && <Pencil size={15} style={{ cursor: "pointer", color: COLORS.navy, marginRight: 12 }} onClick={() => setModal({ mode: "edit", data: s })} />}
                  {canDelete && <Trash2 size={15} style={{ cursor: "pointer", color: COLORS.red }} onClick={() => remove(s.id)} />}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {modal && (
        <Modal title={modal.mode === "add" ? "Add student" : "Edit student"} onClose={() => setModal(null)}>
          <StudentForm initial={modal.data} onSave={save} />
        </Modal>
      )}
    </div>
  );
}

function StudentForm({ initial, onSave }) {
  const [form, setForm] = useState({
    name: initial.name || "", roll: initial.roll || "", cls: initial.cls || "CSE-3A",
    email: initial.email || "", phone: initial.phone || "", admission: initial.admission || "2026-01-01",
    gpa: initial.gpa ?? "",
  });
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSave(form); }}>
      <Field label="Full name"><input style={inputStyle} value={form.name} onChange={set("name")} required /></Field>
      <Field label="Roll number"><input style={inputStyle} value={form.roll} onChange={set("roll")} required /></Field>
      <Field label="Class / section">
        <select style={inputStyle} value={form.cls} onChange={set("cls")}>
          <option>CSE-3A</option><option>CSE-3B</option>
        </select>
      </Field>
      <Field label="Email"><input type="email" style={inputStyle} value={form.email} onChange={set("email")} required /></Field>
      <Field label="Phone"><input style={inputStyle} value={form.phone} onChange={set("phone")} /></Field>
      <Field label="GPA"><input type="number" step="0.1" min="0" max="10" style={inputStyle} value={form.gpa} onChange={set("gpa")} /></Field>
      <Button type="submit" variant="orange" style={{ width: "100%", justifyContent: "center", marginTop: 6 }}>Save student</Button>
    </form>
  );
}
