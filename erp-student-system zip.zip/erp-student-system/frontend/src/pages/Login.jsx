import React, { useState, useEffect } from "react";
import { Users, GraduationCap, ShieldCheck } from "lucide-react";
import { COLORS, FONT_IMPORT, inputStyle } from "../styles/theme.js";
import { Field, Button } from "../components/ui.jsx";
import { api } from "../api.js";

export default function Login({ onLogin }) {
  const [role, setRole] = useState("admin");
  const [users, setUsers] = useState([]);
  const [picked, setPicked] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    api.listUsers(role).then((rows) => {
      setUsers(rows);
      setPicked(rows[0]?.id || "");
    }).catch((e) => setError(e.message));
  }, [role]);

  const roles = [
    { key: "admin", label: "Admin", icon: ShieldCheck },
    { key: "faculty", label: "Faculty", icon: GraduationCap },
    { key: "student", label: "Student", icon: Users },
  ];

  async function handleLogin() {
    if (!picked) return;
    setLoading(true);
    setError("");
    try {
      const user = await api.login(picked);
      onLogin(user);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{
      minHeight: "100vh", background: `linear-gradient(160deg, ${COLORS.navyDark}, ${COLORS.navy})`,
      display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Inter, sans-serif", padding: 16,
    }}>
      <style>{FONT_IMPORT}</style>
      <div style={{ width: 400, maxWidth: "100%", background: COLORS.parchment, borderRadius: 18, padding: 32 }}>
        <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 6 }}>
          <span style={{ width: 12, height: 12, borderRadius: "50%", background: COLORS.orange, display: "inline-block" }} />
          <span style={{ width: 10, height: 10, borderRadius: "50%", background: COLORS.teal, display: "inline-block" }} />
        </div>
        <h1 style={{ fontFamily: "Fraunces, serif", fontSize: 26, margin: "4px 0 2px", color: COLORS.ink, lineHeight: 1.15 }}>
          ERP Student<br />Management System
        </h1>
        <p style={{ color: COLORS.muted, fontSize: 13.5, margin: "0 0 24px" }}>One dashboard. Admin, Faculty and Student views.</p>

        <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
          {roles.map((r) => (
            <button key={r.key} onClick={() => setRole(r.key)} style={{
              flex: 1, padding: "10px 6px", borderRadius: 9, cursor: "pointer",
              border: role === r.key ? `2px solid ${COLORS.navy}` : "1px solid #DDD3BC",
              background: role === r.key ? "#fff" : "transparent",
              display: "flex", flexDirection: "column", alignItems: "center", gap: 4,
            }}>
              <r.icon size={17} color={role === r.key ? COLORS.navy : COLORS.muted} />
              <span style={{ fontSize: 12, fontWeight: 600, color: role === r.key ? COLORS.navy : COLORS.muted }}>{r.label}</span>
            </button>
          ))}
        </div>

        <Field label="Sign in as">
          <select style={inputStyle} value={picked} onChange={(e) => setPicked(e.target.value)}>
            {users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
          </select>
        </Field>

        {error && <p style={{ color: COLORS.red, fontSize: 12.5, marginTop: -6 }}>{error}</p>}

        <Button variant="orange" style={{ width: "100%", justifyContent: "center", marginTop: 8, padding: "11px 16px" }}
          onClick={handleLogin}>
          {loading ? "Signing in…" : "Log in"}
        </Button>
        <p style={{ fontSize: 11.5, color: COLORS.muted, marginTop: 14, textAlign: "center" }}>
          Demo auth — pick any seeded account, no password needed.
        </p>
      </div>
    </div>
  );
}
