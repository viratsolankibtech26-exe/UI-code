import React, { useState, useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Plus } from "lucide-react";
import { COLORS, inputStyle } from "../styles/theme.js";
import { Card, Button, Modal, Field, Pill, PageHeader, SectionLabel } from "../components/ui.jsx";
import { SUBJECTS, grade } from "../constants.js";
import { api } from "../api.js";

export default function FeesResultsPage({ students, fees, refreshFees, results, refreshResults, canEdit, user }) {
  const [gradeModal, setGradeModal] = useState(null);
  const [error, setError] = useState("");
  const visibleStudents = user.role === "student" ? students.filter((s) => s.id === user.studentId) : students;

  async function updateFeeStatus(feeId, status) {
    try {
      await api.updateFeeStatus(feeId, status);
      await refreshFees();
    } catch (e) {
      setError(e.message);
    }
  }

  async function saveGrade(form) {
    try {
      await api.saveResult({
        studentId: form.studentId,
        subject: form.subject,
        term: form.term,
        marks: parseInt(form.marks, 10),
        max: 100,
      });
      await refreshResults();
      setGradeModal(null);
    } catch (e) {
      setError(e.message);
    }
  }

  const perfByClass = useMemo(() => {
    const map = {};
    visibleStudents.forEach((s) => (map[s.cls] = map[s.cls] || []));
    results.filter((r) => visibleStudents.some((s) => s.id === r.studentId)).forEach((r) => {
      const st = visibleStudents.find((s) => s.id === r.studentId);
      map[st.cls] = map[st.cls] || [];
      map[st.cls].push((r.marks / r.max) * 100);
    });
    return Object.entries(map).map(([cls, arr]) => ({
      subject: cls, avg: arr.length ? Math.round(arr.reduce((a, b) => a + b, 0) / arr.length) : 0,
    }));
  }, [results, visibleStudents]);

  return (
    <div>
      <PageHeader title="Fees & Results" subtitle="Track fee status, enter grades, review performance." />

      {error && <p style={{ color: COLORS.red, fontSize: 13 }}>{error}</p>}

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 16 }}>
        <Card style={{ flex: 1, minWidth: 320, padding: 0, overflowX: "auto" }}>
          <div style={{ padding: "16px 16px 0" }}><SectionLabel>Fee status</SectionLabel></div>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead>
              <tr style={{ textAlign: "left" }}>
                <th style={{ padding: "8px 14px", fontSize: 11, color: COLORS.muted }}>Student</th>
                <th style={{ padding: "8px 14px", fontSize: 11, color: COLORS.muted }}>Amount</th>
                <th style={{ padding: "8px 14px", fontSize: 11, color: COLORS.muted }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {fees.filter((f) => visibleStudents.some((s) => s.id === f.studentId)).map((f) => {
                const st = students.find((s) => s.id === f.studentId);
                return (
                  <tr key={f.id} style={{ borderTop: `1px solid ${COLORS.parchmentDeep}` }}>
                    <td style={{ padding: "9px 14px", fontWeight: 600 }}>{st?.name}</td>
                    <td style={{ padding: "9px 14px" }}>₹{Number(f.amount).toLocaleString("en-IN")}</td>
                    <td style={{ padding: "9px 14px" }}>
                      {canEdit ? (
                        <select value={f.status} onChange={(e) => updateFeeStatus(f.id, e.target.value)}
                          style={{ ...inputStyle, padding: "4px 8px", width: 110, fontSize: 12.5 }}>
                          <option value="paid">paid</option>
                          <option value="partial">partial</option>
                          <option value="pending">pending</option>
                        </select>
                      ) : <Pill tone={f.status}>{f.status}</Pill>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Card>

        <Card style={{ flex: 1, minWidth: 280 }}>
          <SectionLabel>Performance overview</SectionLabel>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={perfByClass}>
              <CartesianGrid stroke="#E9DCC2" strokeDasharray="3 3" />
              <XAxis dataKey="subject" tick={{ fontSize: 12, fill: COLORS.muted }} />
              <YAxis tick={{ fontSize: 12, fill: COLORS.muted }} domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="avg" name="Avg %" fill={COLORS.green} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
        <SectionLabel>Grades — {SUBJECTS.join(", ")}</SectionLabel>
        {canEdit && <Button variant="orange" onClick={() => setGradeModal({})}><Plus size={14} /> Enter grade</Button>}
      </div>
      <Card style={{ padding: 0, overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13, minWidth: 640 }}>
          <thead>
            <tr style={{ textAlign: "left", background: COLORS.parchmentDeep }}>
              <th style={{ padding: "10px 14px", fontSize: 11.5, color: COLORS.muted, fontWeight: 700 }}>Student</th>
              <th style={{ padding: "10px 14px", fontSize: 11.5, color: COLORS.muted, fontWeight: 700 }}>Subject</th>
              <th style={{ padding: "10px 14px", fontSize: 11.5, color: COLORS.muted, fontWeight: 700 }}>Marks</th>
              <th style={{ padding: "10px 14px", fontSize: 11.5, color: COLORS.muted, fontWeight: 700 }}>Grade</th>
            </tr>
          </thead>
          <tbody>
            {results.filter((r) => visibleStudents.some((s) => s.id === r.studentId)).map((r) => {
              const st = students.find((s) => s.id === r.studentId);
              const pct = Math.round((r.marks / r.max) * 100);
              return (
                <tr key={r.id} style={{ borderTop: `1px solid ${COLORS.parchmentDeep}` }}>
                  <td style={{ padding: "9px 14px", fontWeight: 600 }}>{st?.name}</td>
                  <td style={{ padding: "9px 14px" }}>{r.subject}</td>
                  <td style={{ padding: "9px 14px" }}>{r.marks}/{r.max}</td>
                  <td style={{ padding: "9px 14px" }}><Pill tone={pct >= 60 ? "paid" : pct >= 40 ? "partial" : "pending"}>{grade(pct)}</Pill></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>

      {gradeModal && (
        <Modal title="Enter grade" onClose={() => setGradeModal(null)}>
          <GradeForm students={students} onSave={saveGrade} />
        </Modal>
      )}
    </div>
  );
}

function GradeForm({ students, onSave }) {
  const [form, setForm] = useState({ studentId: students[0]?.id, subject: SUBJECTS[0], term: "Autumn 2026", marks: "" });
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSave(form); }}>
      <Field label="Student">
        <select style={inputStyle} value={form.studentId} onChange={set("studentId")}>
          {students.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
      </Field>
      <Field label="Subject">
        <select style={inputStyle} value={form.subject} onChange={set("subject")}>
          {SUBJECTS.map((s) => <option key={s}>{s}</option>)}
        </select>
      </Field>
      <Field label="Marks (out of 100)">
        <input type="number" min="0" max="100" style={inputStyle} value={form.marks} onChange={set("marks")} required />
      </Field>
      <Button type="submit" variant="orange" style={{ width: "100%", justifyContent: "center", marginTop: 6 }}>Save grade</Button>
    </form>
  );
}
