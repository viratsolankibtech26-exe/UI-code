import React, { useMemo } from "react";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from "recharts";
import { Users, CalendarCheck, Wallet, Award } from "lucide-react";
import { COLORS } from "../styles/theme.js";
import { Card, StatCard, PageHeader, SectionLabel } from "../components/ui.jsx";
import { DATES } from "../constants.js";

export default function Dashboard({ students, attendance, fees, results, user }) {
  const scopedStudents = user.role === "student" ? students.filter((s) => s.id === user.studentId) : students;
  const scopedIds = new Set(scopedStudents.map((s) => s.id));

  const attByStudent = useMemo(() => {
    const map = {};
    attendance.filter((a) => scopedIds.has(a.studentId)).forEach((a) => {
      map[a.studentId] = map[a.studentId] || { p: 0, t: 0 };
      map[a.studentId].t++;
      if (a.status === "present") map[a.studentId].p++;
    });
    return map;
  }, [attendance, students, user]);

  const avgAttendance = useMemo(() => {
    const vals = Object.values(attByStudent);
    if (!vals.length) return 0;
    return Math.round((vals.reduce((s, v) => s + v.p / v.t, 0) / vals.length) * 100);
  }, [attByStudent]);

  const feesScoped = fees.filter((f) => scopedIds.has(f.studentId));
  const paidCount = feesScoped.filter((f) => f.status === "paid").length;
  const feesPct = feesScoped.length ? Math.round((paidCount / feesScoped.length) * 100) : 0;

  const resultsScoped = results.filter((r) => scopedIds.has(r.studentId));
  const avgResult = resultsScoped.length
    ? Math.round(resultsScoped.reduce((s, r) => s + (r.marks / r.max) * 100, 0) / resultsScoped.length)
    : 0;

  const trend = DATES.map((d) => {
    const dayRows = attendance.filter((a) => a.date === `2026-${d}` && scopedIds.has(a.studentId));
    const present = dayRows.filter((a) => a.status === "present").length;
    return { date: d, pct: dayRows.length ? Math.round((present / dayRows.length) * 100) : 0 };
  });

  const feeBreakdown = ["paid", "partial", "pending"].map((status) => ({
    name: status, value: feesScoped.filter((f) => f.status === status).length,
  })).filter((x) => x.value > 0);
  const FEE_COLORS = { paid: COLORS.green, partial: COLORS.orange, pending: COLORS.red };

  const byClass = useMemo(() => {
    const map = {};
    scopedStudents.forEach((s) => {
      map[s.cls] = map[s.cls] || { cls: s.cls, total: 0, count: 0 };
    });
    resultsScoped.forEach((r) => {
      const st = scopedStudents.find((s) => s.id === r.studentId);
      if (!st) return;
      map[st.cls].total += (r.marks / r.max) * 100;
      map[st.cls].count += 1;
    });
    return Object.values(map).map((c) => ({ cls: c.cls, avg: c.count ? Math.round(c.total / c.count) : 0 }));
  }, [scopedStudents, resultsScoped]);

  return (
    <div>
      <PageHeader title={user.role === "student" ? `Welcome back, ${user.name.split(" ")[0]}` : "Dashboard"}
        subtitle="Live snapshot across students, attendance, fees and results." />
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 20 }}>
        <StatCard icon={Users} label={user.role === "student" ? "Your Class" : "Total Students"} value={user.role === "student" ? scopedStudents[0]?.cls || "-" : students.length} accent={COLORS.navy} />
        <StatCard icon={CalendarCheck} label="Avg. Attendance" value={`${avgAttendance}%`} accent={COLORS.teal} />
        <StatCard icon={Wallet} label="Fees Paid" value={`${feesPct}%`} accent={COLORS.orange} />
        <StatCard icon={Award} label="Avg. Result" value={`${avgResult}%`} accent={COLORS.green} />
      </div>

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <Card style={{ flex: 2, minWidth: 340 }}>
          <SectionLabel>Attendance trend</SectionLabel>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={trend}>
              <CartesianGrid stroke="#E9DCC2" strokeDasharray="3 3" />
              <XAxis dataKey="date" tick={{ fontSize: 12, fill: COLORS.muted }} />
              <YAxis tick={{ fontSize: 12, fill: COLORS.muted }} domain={[0, 100]} />
              <Tooltip />
              <Line type="monotone" dataKey="pct" name="Present %" stroke={COLORS.teal} strokeWidth={2.5} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card style={{ flex: 1, minWidth: 240 }}>
          <SectionLabel>Fee status</SectionLabel>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={feeBreakdown} dataKey="value" nameKey="name" innerRadius={45} outerRadius={75} paddingAngle={3}>
                {feeBreakdown.map((entry, i) => <Cell key={i} fill={FEE_COLORS[entry.name]} />)}
              </Pie>
              <Tooltip />
              <Legend wrapperStyle={{ fontSize: 12, textTransform: "capitalize" }} />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {user.role !== "student" && (
        <Card style={{ marginTop: 16 }}>
          <SectionLabel>Class-wise average result</SectionLabel>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={byClass}>
              <CartesianGrid stroke="#E9DCC2" strokeDasharray="3 3" />
              <XAxis dataKey="cls" tick={{ fontSize: 12, fill: COLORS.muted }} />
              <YAxis tick={{ fontSize: 12, fill: COLORS.muted }} domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="avg" name="Avg %" fill={COLORS.orange} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      )}
    </div>
  );
}
