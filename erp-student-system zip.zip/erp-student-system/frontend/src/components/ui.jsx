import React from "react";
import { X } from "lucide-react";
import { COLORS } from "../styles/theme.js";

export function Card({ children, style, className = "" }) {
  return (
    <div
      className={className}
      style={{
        background: COLORS.parchment,
        border: `1px solid ${COLORS.parchmentDeep}`,
        borderRadius: 14,
        padding: 20,
        ...style,
      }}
    >
      {children}
    </div>
  );
}

export function StatCard({ icon: Icon, label, value, accent }) {
  return (
    <Card style={{ display: "flex", alignItems: "center", gap: 14, flex: 1, minWidth: 180 }}>
      <div style={{
        width: 42, height: 42, borderRadius: 10, background: accent,
        display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
      }}>
        <Icon size={20} color="#fff" />
      </div>
      <div>
        <div style={{ fontSize: 12, color: COLORS.muted, fontWeight: 600, letterSpacing: 0.2 }}>{label}</div>
        <div style={{ fontSize: 24, fontFamily: "Fraunces, serif", fontWeight: 600, color: COLORS.ink }}>{value}</div>
      </div>
    </Card>
  );
}

export function Pill({ children, tone = "muted" }) {
  const map = {
    paid: { bg: "#DCEBDD", fg: COLORS.green },
    partial: { bg: "#FBEBD9", fg: COLORS.orange },
    pending: { bg: "#F6DCDA", fg: COLORS.red },
    muted: { bg: "#E9E2D2", fg: COLORS.muted },
  };
  const c = map[tone] || map.muted;
  return (
    <span style={{
      background: c.bg, color: c.fg, fontSize: 12, fontWeight: 600,
      padding: "3px 10px", borderRadius: 999, textTransform: "capitalize",
    }}>{children}</span>
  );
}

export function Button({ children, onClick, variant = "solid", style, type = "button" }) {
  const base = {
    fontFamily: "Inter, sans-serif", fontWeight: 600, fontSize: 13.5,
    padding: "9px 16px", borderRadius: 9, cursor: "pointer", border: "none",
    display: "inline-flex", alignItems: "center", gap: 6, transition: "opacity .15s",
  };
  const variants = {
    solid: { background: COLORS.navy, color: "#fff" },
    orange: { background: COLORS.orange, color: "#fff" },
    ghost: { background: "transparent", color: COLORS.navy, border: `1px solid ${COLORS.parchmentDeep}` },
    danger: { background: "transparent", color: COLORS.red, border: `1px solid #E9C7C3` },
  };
  return (
    <button type={type} onClick={onClick} style={{ ...base, ...variants[variant], ...style }}
      onMouseOver={(e) => (e.currentTarget.style.opacity = 0.85)}
      onMouseOut={(e) => (e.currentTarget.style.opacity = 1)}>
      {children}
    </button>
  );
}

export function Modal({ title, onClose, children }) {
  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(38,52,76,0.45)",
      display: "flex", alignItems: "center", justifyContent: "center", zIndex: 50, padding: 16,
    }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} style={{
        background: "#fff", borderRadius: 14, padding: 24, width: 460, maxWidth: "100%",
        maxHeight: "88vh", overflowY: "auto",
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <h3 style={{ fontFamily: "Fraunces, serif", fontSize: 19, margin: 0, color: COLORS.ink }}>{title}</h3>
          <X size={18} style={{ cursor: "pointer", color: COLORS.muted }} onClick={onClose} />
        </div>
        {children}
      </div>
    </div>
  );
}

export function Field({ label, children }) {
  return (
    <label style={{ display: "block", marginBottom: 12 }}>
      <div style={{ fontSize: 12.5, fontWeight: 600, color: COLORS.muted, marginBottom: 5 }}>{label}</div>
      {children}
    </label>
  );
}

export function PageHeader({ title, subtitle }) {
  return (
    <div style={{ marginBottom: 20 }}>
      <h2 style={{ fontFamily: "Fraunces, serif", fontSize: 24, margin: "0 0 4px", color: COLORS.ink }}>{title}</h2>
      <p style={{ color: COLORS.muted, fontSize: 13.5, margin: 0 }}>{subtitle}</p>
    </div>
  );
}

export function SectionLabel({ children }) {
  return <div style={{ fontSize: 12.5, fontWeight: 700, color: COLORS.navy, marginBottom: 10, letterSpacing: 0.2 }}>{children}</div>;
}
