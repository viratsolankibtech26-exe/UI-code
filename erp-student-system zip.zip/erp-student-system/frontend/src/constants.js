export const SUBJECTS = ["Data Structures", "Operating Systems", "DBMS", "Computer Networks"];

// Sample date range used for the attendance trend charts (MM-DD, year 2026).
export const DATES = ["09-08", "09-09", "09-10", "09-11", "09-12", "09-13", "09-15"];

export function grade(pct) {
  if (pct >= 90) return "A+";
  if (pct >= 80) return "A";
  if (pct >= 70) return "B";
  if (pct >= 60) return "C";
  if (pct >= 50) return "D";
  return "F";
}
