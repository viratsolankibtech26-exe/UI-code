-- ---------------------------------------------------------------
-- Campus ERP Student Management System — Schema
-- PostgreSQL
-- ---------------------------------------------------------------

CREATE TABLE IF NOT EXISTS students (
  id            VARCHAR(20)   PRIMARY KEY,
  name          VARCHAR(120)  NOT NULL,
  roll          VARCHAR(30)   NOT NULL UNIQUE,
  cls           VARCHAR(30)   NOT NULL,
  email         VARCHAR(150)  NOT NULL,
  phone         VARCHAR(30),
  admission     DATE,
  gpa           NUMERIC(3,1)  DEFAULT 0,
  created_at    TIMESTAMPTZ   NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ   NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id            VARCHAR(20)   PRIMARY KEY,
  name          VARCHAR(120)  NOT NULL,
  role          VARCHAR(20)   NOT NULL CHECK (role IN ('admin', 'faculty', 'student')),
  student_id    VARCHAR(20)   REFERENCES students(id) ON DELETE SET NULL,
  created_at    TIMESTAMPTZ   NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS attendance (
  id            VARCHAR(20)   PRIMARY KEY,
  student_id    VARCHAR(20)   NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  date          DATE          NOT NULL,
  status        VARCHAR(10)   NOT NULL CHECK (status IN ('present', 'absent')),
  created_at    TIMESTAMPTZ   NOT NULL DEFAULT now(),
  UNIQUE (student_id, date)
);

CREATE TABLE IF NOT EXISTS fees (
  id            VARCHAR(20)   PRIMARY KEY,
  student_id    VARCHAR(20)   NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  term          VARCHAR(50)   NOT NULL,
  amount        NUMERIC(10,2) NOT NULL,
  status        VARCHAR(10)   NOT NULL CHECK (status IN ('paid', 'partial', 'pending')),
  due_date      DATE,
  created_at    TIMESTAMPTZ   NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ   NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS results (
  id            VARCHAR(20)   PRIMARY KEY,
  student_id    VARCHAR(20)   NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  subject       VARCHAR(100)  NOT NULL,
  term          VARCHAR(50)   NOT NULL,
  marks         INTEGER       NOT NULL CHECK (marks >= 0),
  max           INTEGER       NOT NULL DEFAULT 100,
  created_at    TIMESTAMPTZ   NOT NULL DEFAULT now(),
  UNIQUE (student_id, subject, term)
);

CREATE INDEX IF NOT EXISTS idx_attendance_student_date ON attendance (student_id, date);
CREATE INDEX IF NOT EXISTS idx_fees_student ON fees (student_id);
CREATE INDEX IF NOT EXISTS idx_results_student ON results (student_id);
CREATE INDEX IF NOT EXISTS idx_students_cls ON students (cls);
