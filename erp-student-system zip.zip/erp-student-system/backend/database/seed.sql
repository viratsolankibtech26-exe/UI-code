-- ---------------------------------------------------------------
-- Campus ERP Student Management System — Seed data
-- Mirrors the demo data from the original front-end prototype.
-- Safe to re-run: existing rows are upserted.
-- ---------------------------------------------------------------

-- Students
INSERT INTO students (id, name, roll, cls, email, phone, admission, gpa) VALUES
  ('s1', 'Aarav Mehta',   'CS101', 'CSE-3A', 'aarav.m@campus.edu',   '98200 11223', '2024-07-12', 8.6),
  ('s2', 'Diya Shah',     'CS102', 'CSE-3A', 'diya.s@campus.edu',    '98200 22334', '2024-07-12', 9.1),
  ('s3', 'Kabir Rao',     'CS103', 'CSE-3A', 'kabir.r@campus.edu',   '98200 33445', '2024-07-12', 7.4),
  ('s4', 'Ananya Iyer',   'CS104', 'CSE-3B', 'ananya.i@campus.edu',  '98200 44556', '2024-07-13', 8.9),
  ('s5', 'Vihaan Joshi',  'CS105', 'CSE-3B', 'vihaan.j@campus.edu',  '98200 55667', '2024-07-13', 6.8),
  ('s6', 'Ishita Nair',   'CS106', 'CSE-3B', 'ishita.n@campus.edu',  '98200 66778', '2024-07-14', 9.4),
  ('s7', 'Reyansh Gupta', 'CS107', 'CSE-3A', 'reyansh.g@campus.edu', '98200 77889', '2024-07-14', 7.9),
  ('s8', 'Myra Desai',    'CS108', 'CSE-3B', 'myra.d@campus.edu',    '98200 88990', '2024-07-15', 8.2)
ON CONFLICT (id) DO NOTHING;

-- Demo users (passwordless demo auth — mirrors the "pick any seeded account" login)
INSERT INTO users (id, name, role, student_id) VALUES
  ('u1', 'Bunty (Admin)',        'admin',   NULL),
  ('u2', 'Prof. Raj Aryan',      'faculty', NULL),
  ('u3', 'Prof. Kartik Shah',    'faculty', NULL),
  ('u4', 'Aarav Mehta',          'student', 's1'),
  ('u5', 'Ishita Nair',          'student', 's6')
ON CONFLICT (id) DO NOTHING;

-- Fees — one row per student for the Autumn 2026 term
INSERT INTO fees (id, student_id, term, amount, status, due_date) VALUES
  ('f0', 's1', 'Autumn 2026', 45000, 'pending', '2026-09-30'),
  ('f1', 's2', 'Autumn 2026', 45000, 'partial', '2026-09-30'),
  ('f2', 's3', 'Autumn 2026', 45000, 'paid',    '2026-09-30'),
  ('f3', 's4', 'Autumn 2026', 45000, 'paid',    '2026-09-30'),
  ('f4', 's5', 'Autumn 2026', 45000, 'pending', '2026-09-30'),
  ('f5', 's6', 'Autumn 2026', 45000, 'partial', '2026-09-30'),
  ('f6', 's7', 'Autumn 2026', 45000, 'paid',    '2026-09-30'),
  ('f7', 's8', 'Autumn 2026', 45000, 'paid',    '2026-09-30')
ON CONFLICT (id) DO NOTHING;

-- Attendance — 7 sample dates across the roster.
-- Vihaan Joshi (s5) is seeded with a noticeably lower attendance rate,
-- everyone else is mostly present, to mirror the original demo skew.
INSERT INTO attendance (id, student_id, date, status)
SELECT
  'a' || row_number() OVER (),
  student_id,
  date,
  status
FROM (VALUES
  ('s1', DATE '2026-09-08', 'present'), ('s1', DATE '2026-09-09', 'present'), ('s1', DATE '2026-09-10', 'present'), ('s1', DATE '2026-09-11', 'absent'),  ('s1', DATE '2026-09-12', 'present'), ('s1', DATE '2026-09-13', 'present'), ('s1', DATE '2026-09-15', 'present'),
  ('s2', DATE '2026-09-08', 'present'), ('s2', DATE '2026-09-09', 'present'), ('s2', DATE '2026-09-10', 'present'), ('s2', DATE '2026-09-11', 'present'), ('s2', DATE '2026-09-12', 'present'), ('s2', DATE '2026-09-13', 'absent'),  ('s2', DATE '2026-09-15', 'present'),
  ('s3', DATE '2026-09-08', 'present'), ('s3', DATE '2026-09-09', 'absent'),  ('s3', DATE '2026-09-10', 'present'), ('s3', DATE '2026-09-11', 'present'), ('s3', DATE '2026-09-12', 'present'), ('s3', DATE '2026-09-13', 'present'), ('s3', DATE '2026-09-15', 'present'),
  ('s4', DATE '2026-09-08', 'present'), ('s4', DATE '2026-09-09', 'present'), ('s4', DATE '2026-09-10', 'present'), ('s4', DATE '2026-09-11', 'present'), ('s4', DATE '2026-09-12', 'absent'),  ('s4', DATE '2026-09-13', 'present'), ('s4', DATE '2026-09-15', 'present'),
  ('s5', DATE '2026-09-08', 'absent'),  ('s5', DATE '2026-09-09', 'present'), ('s5', DATE '2026-09-10', 'absent'),  ('s5', DATE '2026-09-11', 'absent'),  ('s5', DATE '2026-09-12', 'present'), ('s5', DATE '2026-09-13', 'absent'),  ('s5', DATE '2026-09-15', 'present'),
  ('s6', DATE '2026-09-08', 'present'), ('s6', DATE '2026-09-09', 'present'), ('s6', DATE '2026-09-10', 'present'), ('s6', DATE '2026-09-11', 'present'), ('s6', DATE '2026-09-12', 'present'), ('s6', DATE '2026-09-13', 'present'), ('s6', DATE '2026-09-15', 'present'),
  ('s7', DATE '2026-09-08', 'present'), ('s7', DATE '2026-09-09', 'present'), ('s7', DATE '2026-09-10', 'absent'),  ('s7', DATE '2026-09-11', 'present'), ('s7', DATE '2026-09-12', 'present'), ('s7', DATE '2026-09-13', 'present'), ('s7', DATE '2026-09-15', 'present'),
  ('s8', DATE '2026-09-08', 'present'), ('s8', DATE '2026-09-09', 'present'), ('s8', DATE '2026-09-10', 'present'), ('s8', DATE '2026-09-11', 'present'), ('s8', DATE '2026-09-12', 'present'), ('s8', DATE '2026-09-13', 'present'), ('s8', DATE '2026-09-15', 'absent')
) AS v(student_id, date, status)
ON CONFLICT (student_id, date) DO NOTHING;

-- Results — 4 subjects per student for the Autumn 2026 term
INSERT INTO results (id, student_id, subject, term, marks, max)
SELECT
  'r' || row_number() OVER (),
  student_id, subject, 'Autumn 2026', marks, 100
FROM (VALUES
  ('s1', 'Data Structures', 78), ('s1', 'Operating Systems', 82), ('s1', 'DBMS', 75), ('s1', 'Computer Networks', 88),
  ('s2', 'Data Structures', 91), ('s2', 'Operating Systems', 89), ('s2', 'DBMS', 94), ('s2', 'Computer Networks', 87),
  ('s3', 'Data Structures', 66), ('s3', 'Operating Systems', 71), ('s3', 'DBMS', 68), ('s3', 'Computer Networks', 74),
  ('s4', 'Data Structures', 85), ('s4', 'Operating Systems', 90), ('s4', 'DBMS', 83), ('s4', 'Computer Networks', 92),
  ('s5', 'Data Structures', 58), ('s5', 'Operating Systems', 62), ('s5', 'DBMS', 55), ('s5', 'Computer Networks', 60),
  ('s6', 'Data Structures', 95), ('s6', 'Operating Systems', 93), ('s6', 'DBMS', 97), ('s6', 'Computer Networks', 91),
  ('s7', 'Data Structures', 73), ('s7', 'Operating Systems', 79), ('s7', 'DBMS', 76), ('s7', 'Computer Networks', 81),
  ('s8', 'Data Structures', 80), ('s8', 'Operating Systems', 84), ('s8', 'DBMS', 78), ('s8', 'Computer Networks', 86)
) AS v(student_id, subject, marks)
ON CONFLICT (student_id, subject, term) DO NOTHING;
