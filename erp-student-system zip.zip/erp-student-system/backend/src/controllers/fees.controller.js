const pool = require("../config/db");
const { generateId } = require("../utils/id");

const SELECT_COLUMNS = `
  id, student_id AS "studentId", term, amount, status,
  to_char(due_date, 'YYYY-MM-DD') AS "dueDate"
`;

async function listFees(req, res, next) {
  try {
    const { studentId } = req.query;
    const params = [];
    let where = "";
    if (studentId) {
      params.push(studentId);
      where = "WHERE student_id = $1";
    }
    const { rows } = await pool.query(`SELECT ${SELECT_COLUMNS} FROM fees ${where} ORDER BY id`, params);
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

async function createFee(req, res, next) {
  try {
    const { studentId, term, amount, status, dueDate } = req.body;
    if (!studentId || !term || amount == null || !status) {
      return res.status(400).json({ error: "studentId, term, amount and status are required" });
    }
    const id = generateId("f");
    const { rows } = await pool.query(
      `INSERT INTO fees (id, student_id, term, amount, status, due_date)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING ${SELECT_COLUMNS}`,
      [id, studentId, term, amount, status, dueDate || null]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    next(err);
  }
}

// PATCH /api/fees/:id  { status }
async function updateFeeStatus(req, res, next) {
  try {
    const { status } = req.body;
    if (!["paid", "partial", "pending"].includes(status)) {
      return res.status(400).json({ error: "status must be paid, partial or pending" });
    }
    const { rows } = await pool.query(
      `UPDATE fees SET status = $1, updated_at = now() WHERE id = $2 RETURNING ${SELECT_COLUMNS}`,
      [status, req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: "Fee record not found" });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

module.exports = { listFees, createFee, updateFeeStatus };
