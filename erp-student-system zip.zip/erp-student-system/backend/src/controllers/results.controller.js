const pool = require("../config/db");
const { generateId } = require("../utils/id");

const SELECT_COLUMNS = `
  id, student_id AS "studentId", subject, term, marks, max
`;

async function listResults(req, res, next) {
  try {
    const { studentId } = req.query;
    const params = [];
    let where = "";
    if (studentId) {
      params.push(studentId);
      where = "WHERE student_id = $1";
    }
    const { rows } = await pool.query(`SELECT ${SELECT_COLUMNS} FROM results ${where} ORDER BY id`, params);
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

// POST /api/results  { studentId, subject, term, marks, max }
// Upserts on (student, subject, term) — matches the original "enter grade"
// behaviour which replaces any existing grade for the same subject/term.
async function saveResult(req, res, next) {
  try {
    const { studentId, subject, term, marks, max } = req.body;
    if (!studentId || !subject || !term || marks == null) {
      return res.status(400).json({ error: "studentId, subject, term and marks are required" });
    }
    const id = generateId("r");
    const { rows } = await pool.query(
      `INSERT INTO results (id, student_id, subject, term, marks, max)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (student_id, subject, term)
       DO UPDATE SET marks = EXCLUDED.marks, max = EXCLUDED.max
       RETURNING ${SELECT_COLUMNS}`,
      [id, studentId, subject, term, marks, max || 100]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    next(err);
  }
}

module.exports = { listResults, saveResult };
