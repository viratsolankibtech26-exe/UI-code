const pool = require("../config/db");
const { generateId } = require("../utils/id");

const SELECT_COLUMNS = `
  id, student_id AS "studentId", to_char(date, 'YYYY-MM-DD') AS date, status
`;

// GET /api/attendance?date=YYYY-MM-DD&studentId=s1
async function listAttendance(req, res, next) {
  try {
    const { date, studentId } = req.query;
    const conditions = [];
    const params = [];

    if (date) {
      params.push(date);
      conditions.push(`date = $${params.length}`);
    }
    if (studentId) {
      params.push(studentId);
      conditions.push(`student_id = $${params.length}`);
    }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const { rows } = await pool.query(
      `SELECT ${SELECT_COLUMNS} FROM attendance ${where} ORDER BY date`,
      params
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

// POST /api/attendance  { studentId, date, status }
// Upserts — marking the same student/date again updates the status,
// mirroring the original "toggle" behaviour.
async function markAttendance(req, res, next) {
  try {
    const { studentId, date, status } = req.body;
    if (!studentId || !date || !status) {
      return res.status(400).json({ error: "studentId, date and status are required" });
    }
    if (!["present", "absent"].includes(status)) {
      return res.status(400).json({ error: "status must be 'present' or 'absent'" });
    }

    const id = generateId("a");
    const { rows } = await pool.query(
      `INSERT INTO attendance (id, student_id, date, status)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (student_id, date)
       DO UPDATE SET status = EXCLUDED.status
       RETURNING ${SELECT_COLUMNS}`,
      [id, studentId, date, status]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    next(err);
  }
}

module.exports = { listAttendance, markAttendance };
