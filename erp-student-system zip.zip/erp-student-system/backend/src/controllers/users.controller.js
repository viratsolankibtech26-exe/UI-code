const pool = require("../config/db");

// GET /api/users — list demo accounts (used to populate the login screen)
async function listUsers(req, res, next) {
  try {
    const { role } = req.query;
    const params = [];
    let query = "SELECT id, name, role, student_id AS \"studentId\" FROM users";
    if (role) {
      params.push(role);
      query += " WHERE role = $1";
    }
    query += " ORDER BY name";
    const { rows } = await pool.query(query, params);
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

// POST /api/auth/login  { userId } — demo/passwordless auth, matches the
// original prototype's "pick any seeded account, no password" flow.
async function login(req, res, next) {
  try {
    const { userId } = req.body;
    if (!userId) return res.status(400).json({ error: "userId is required" });

    const { rows } = await pool.query(
      'SELECT id, name, role, student_id AS "studentId" FROM users WHERE id = $1',
      [userId]
    );
    if (!rows.length) return res.status(404).json({ error: "User not found" });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

module.exports = { listUsers, login };
