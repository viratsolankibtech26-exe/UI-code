const pool = require("../config/db");
const { generateId } = require("../utils/id");

const SELECT_COLUMNS = `
  id, name, roll, cls, email, phone,
  to_char(admission, 'YYYY-MM-DD') AS admission,
  gpa
`;

async function listStudents(req, res, next) {
  try {
    const { rows } = await pool.query(`SELECT ${SELECT_COLUMNS} FROM students ORDER BY roll`);
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

async function getStudent(req, res, next) {
  try {
    const { rows } = await pool.query(`SELECT ${SELECT_COLUMNS} FROM students WHERE id = $1`, [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: "Student not found" });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

async function createStudent(req, res, next) {
  try {
    const { name, roll, cls, email, phone, admission, gpa } = req.body;
    if (!name || !roll || !cls || !email) {
      return res.status(400).json({ error: "name, roll, cls and email are required" });
    }
    const id = generateId("s");
    const { rows } = await pool.query(
      `INSERT INTO students (id, name, roll, cls, email, phone, admission, gpa)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING ${SELECT_COLUMNS}`,
      [id, name, roll, cls, email, phone || null, admission || null, gpa || 0]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    next(err);
  }
}

async function updateStudent(req, res, next) {
  try {
    const { name, roll, cls, email, phone, admission, gpa } = req.body;
    const { rows } = await pool.query(
      `UPDATE students SET
         name = COALESCE($1, name),
         roll = COALESCE($2, roll),
         cls = COALESCE($3, cls),
         email = COALESCE($4, email),
         phone = COALESCE($5, phone),
         admission = COALESCE($6, admission),
         gpa = COALESCE($7, gpa),
         updated_at = now()
       WHERE id = $8
       RETURNING ${SELECT_COLUMNS}`,
      [name, roll, cls, email, phone, admission, gpa, req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: "Student not found" });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

async function deleteStudent(req, res, next) {
  try {
    const { rowCount } = await pool.query("DELETE FROM students WHERE id = $1", [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: "Student not found" });
    res.status(204).end();
  } catch (err) {
    next(err);
  }
}

module.exports = { listStudents, getStudent, createStudent, updateStudent, deleteStudent };
