function generateId(prefix = "") {
  return `${prefix}${Math.random().toString(36).slice(2, 10)}`;
}

module.exports = { generateId };
