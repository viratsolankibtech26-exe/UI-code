/**
 * One-off helper: applies database/schema.sql then database/seed.sql
 * against the database configured in .env.
 *
 * Usage:  npm run db:setup
 */
const fs = require("fs");
const path = require("path");
const pool = require("./db");

async function runSqlFile(filePath) {
  const sql = fs.readFileSync(filePath, "utf8");
  await pool.query(sql);
  console.log(`Applied ${path.basename(filePath)}`);
}

(async () => {
  try {
    const dbDir = path.join(__dirname, "..", "..", "database");
    await runSqlFile(path.join(dbDir, "schema.sql"));
    await runSqlFile(path.join(dbDir, "seed.sql"));
    console.log("Database setup complete.");
  } catch (err) {
    console.error("Database setup failed:", err.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
})();
