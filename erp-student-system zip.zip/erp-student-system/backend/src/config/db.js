const { Pool } = require("pg");
require("dotenv").config();

const useSSL = String(process.env.PGSSL).toLowerCase() === "true";

// Prefer a single DATABASE_URL (common for hosted Postgres providers),
// falling back to discrete PG* fields for local development.
const pool = process.env.DATABASE_URL
  ? new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: useSSL ? { rejectUnauthorized: false } : false,
    })
  : new Pool({
      host: process.env.PGHOST,
      port: Number(process.env.PGPORT) || 5432,
      database: process.env.PGDATABASE,
      user: process.env.PGUSER,
      password: process.env.PGPASSWORD,
      ssl: useSSL ? { rejectUnauthorized: false } : false,
    });

pool.on("error", (err) => {
  console.error("Unexpected PostgreSQL pool error", err);
});

module.exports = pool;
