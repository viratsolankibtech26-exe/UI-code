const express = require("express");
const { listFees, createFee, updateFeeStatus } = require("../controllers/fees.controller");

const router = express.Router();

router.get("/", listFees);
router.post("/", createFee);
router.patch("/:id", updateFeeStatus);

module.exports = router;
