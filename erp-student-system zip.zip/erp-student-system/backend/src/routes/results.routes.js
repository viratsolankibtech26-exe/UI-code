const express = require("express");
const { listResults, saveResult } = require("../controllers/results.controller");

const router = express.Router();

router.get("/", listResults);
router.post("/", saveResult);

module.exports = router;
