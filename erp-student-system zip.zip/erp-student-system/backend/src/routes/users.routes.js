const express = require("express");
const { listUsers, login } = require("../controllers/users.controller");

const router = express.Router();

router.get("/", listUsers);
router.post("/login", login);

module.exports = router;
