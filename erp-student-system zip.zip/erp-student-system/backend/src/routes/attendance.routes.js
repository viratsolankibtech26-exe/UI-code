const express = require("express");
const { listAttendance, markAttendance } = require("../controllers/attendance.controller");

const router = express.Router();

router.get("/", listAttendance);
router.post("/", markAttendance);

module.exports = router;
