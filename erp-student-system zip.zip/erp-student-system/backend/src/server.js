require("dotenv").config();
const express = require("express");
const cors = require("cors");

const usersRoutes = require("./routes/users.routes");
const studentsRoutes = require("./routes/students.routes");
const attendanceRoutes = require("./routes/attendance.routes");
const feesRoutes = require("./routes/fees.routes");
const resultsRoutes = require("./routes/results.routes");

const app = express();

const allowedOrigins = (process.env.CLIENT_ORIGIN || "http://localhost:5173")
  .split(",")
  .map((o) => o.trim());

app.use(cors({ origin: allowedOrigins }));
app.use(express.json());

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

app.use("/api/users", usersRoutes);
app.use("/api/students", studentsRoutes);
app.use("/api/attendance", attendanceRoutes);
app.use("/api/fees", feesRoutes);
app.use("/api/results", resultsRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: "Not found" });
});

// Central error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || "Internal server error" });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`ERP backend listening on port ${PORT}`);
});

module.exports = app;
