# Campus ERP — Student Management System

A full-stack ERP-style student management system with role-based views for
**Admin**, **Faculty**, and **Student** users — dashboard analytics, student
records, attendance tracking, and fees & results management.

This project was converted from a front-end-only prototype into a complete
full-stack app: a **React (Vite)** frontend backed by an **Express + PostgreSQL**
REST API.

## Stack

- **Frontend:** React 18, Vite, Recharts (charts), Lucide React (icons)
- **Backend:** Node.js, Express, `pg` (PostgreSQL driver)
- **Database:** PostgreSQL

## Project structure

```
erp-student-system/
├── backend/
│   ├── database/
│   │   ├── schema.sql        # table definitions
│   │   └── seed.sql          # demo data (students, users, fees, attendance, results)
│   ├── src/
│   │   ├── config/           # db pool + db setup script
│   │   ├── controllers/      # request handlers
│   │   ├── routes/           # Express routers
│   │   ├── utils/
│   │   └── server.js         # app entry point
│   ├── .env.example
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── components/ui.jsx # shared UI primitives (Card, Button, Modal, etc.)
│   │   ├── pages/             # Login, Dashboard, Students, Attendance, Fees & Results
│   │   ├── styles/theme.js    # design tokens / colors / responsive CSS
│   │   ├── api.js             # fetch wrapper for the backend API
│   │   ├── constants.js
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── index.html
│   ├── .env.example
│   └── package.json
├── docker-compose.yml         # optional local PostgreSQL container
└── .gitignore
```

## Prerequisites

- Node.js 18+
- PostgreSQL 14+ (local install, or use the included `docker-compose.yml`)

## 1. Database setup

**Option A — Docker (quickest):**

```bash
docker compose up -d
```

This starts PostgreSQL on `localhost:5432` with credentials matching
`backend/.env.example`.

**Option B — existing PostgreSQL install:**

Create a database and user matching whatever you put in `backend/.env`:

```sql
CREATE DATABASE erp_student_system;
CREATE USER erp_user WITH ENCRYPTED PASSWORD 'erp_password';
GRANT ALL PRIVILEGES ON DATABASE erp_student_system TO erp_user;
```

Then apply the schema and seed data:

```bash
psql -U erp_user -d erp_student_system -f backend/database/schema.sql
psql -U erp_user -d erp_student_system -f backend/database/seed.sql
```

(Or, after configuring `backend/.env`, run `npm run db:setup` from `backend/`
— see below — which applies both files for you.)

## 2. Backend setup

```bash
cd backend
cp .env.example .env      # then edit values if needed
npm install
npm run db:setup          # applies schema.sql + seed.sql via the configured DB
npm run dev                # starts the API on http://localhost:5000
```

Health check: `GET http://localhost:5000/api/health`

### API overview

| Method | Endpoint                  | Description                              |
|--------|----------------------------|-------------------------------------------|
| GET    | `/api/users?role=admin`    | List demo accounts (for the login screen) |
| POST   | `/api/users/login`         | Demo login — `{ userId }` (no password)   |
| GET    | `/api/students`            | List students                             |
| POST   | `/api/students`            | Create student                            |
| PUT    | `/api/students/:id`        | Update student                            |
| DELETE | `/api/students/:id`        | Delete student                            |
| GET    | `/api/attendance`          | List attendance (`?date=`, `?studentId=`) |
| POST   | `/api/attendance`          | Mark/toggle attendance                    |
| GET    | `/api/fees`                | List fee records                          |
| PATCH  | `/api/fees/:id`            | Update fee status                         |
| GET    | `/api/results`             | List results                              |
| POST   | `/api/results`             | Save/update a grade                       |

## 3. Frontend setup

```bash
cd frontend
cp .env.example .env      # points at the backend API URL
npm install
npm run dev                # starts the app on http://localhost:5173
```

Open `http://localhost:5173` — pick a role (Admin / Faculty / Student) and
a seeded demo account to sign in. This is demo authentication only (no
password), matching the original prototype's login flow — **do not use
this auth approach as-is in production**.

## Roles

- **Admin** — full access: manage students (add/edit/delete), mark attendance,
  update fee status, enter grades.
- **Faculty** — manage attendance, fee status, and grades; can add/edit
  students but not delete them.
- **Student** — read-only view scoped to their own record.

## Notes on productionizing

This project ships with demo/passwordless login to mirror the original
prototype. Before deploying for real use, you should add:

- Real authentication (hashed passwords or an identity provider) and
  session/JWT-based auth middleware on the backend
- Input validation/sanitization beyond the basic checks included
- Database migrations tooling (e.g. `node-pg-migrate`) instead of a flat
  `schema.sql`
- HTTPS and proper CORS origin locking in production

## License

MIT — feel free to adapt this for your own coursework/project.
